const fs = require("fs");
const nodemailer = require("nodemailer");
const express = require("express");
const path = require("path");
const bodyParser = require("body-parser");


const app = express();

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "ajbittu804479@gmail.com",
    pass: "Rajb804426@"
  }
});

// View engine
app.set("view engine", "ejs");


// Middleware
app.use(express.static(path.join(__dirname, "public")));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));

// Routes
app.get("/", (req, res) => res.render("home"));
app.get("/services", (req, res) => res.render("services"));
app.get("/portfolio", (req, res) => res.render("portfolio"));
app.get("/order", (req, res) => res.render("order"));
app.get("/contact", (req, res) => res.render("contact"));

// Form handlers
app.post("/order", async (req, res) => {
  const { name, phone, email, message } = req.body;

  if (!name || !phone || !email) {
    return res.status(400).send("All required fields are missing!");
  }
  

  // Email to you
  await transporter.sendMail({
    from: "ajbittu804479@gmail.com",
    to: "ramkrishn804479@gmail.com",
    subject: "📦 New Website Order",
    html: `
      <h2>New Order Received</h2>
      <p><b>Name:</b> ${name}</p>
      <p><b>Phone:</b> ${phone}</p>
      <p><b>Email:</b> ${email}</p>
      <p><b>Message:</b> ${message}</p>
    `
  });

  const path = require("path");

app.get("/order", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "order.html"));
});
res.render("order");
});

app.listen(3000, () => {
  console.log("Server running on http://localhost:3000");
});